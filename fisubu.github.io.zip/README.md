# Summary of videocall applications

The webpage tries to offer to the reader an overview of the different videocall applications available. 
We focused on the more general applications as well as those applications more oriented to the healthcare.

### Created by: Adrián Arnaiz-Rodríguez, Álvar Arnaiz-González & José Díez-Pastor

### Directed by: Esther Cubo

Note: the information was gathered on 12th of April 2021. The cells of the column without information represents that we were unable to confirm the functionality through the web.
